package com.example.nishtha.builditbigger;

/**
 * Created by nishtha on 14/8/16.
 */
public interface AsyncResponse {
    public void processFinish(String joke);
}
